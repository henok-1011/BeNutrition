import React from 'react'

function Catagories() {
  return (
    <div>Catagories</div>
  )
}

export default Catagories